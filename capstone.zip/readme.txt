sebelum membuat env, folder models didalam folder capstone
folder models = https://drive.google.com/file/d/1huB014A9duWAvTxu__IjS-3Q9zhh0mB5/view?usp=share_link
----------------------------------------------
conda create -n capstone python=3.8.5
activate capstone
===============================================
all package

pip install Flask==2.1.0 
pip install Werkzeug==2.1.2 
pip install numpy==1.21.6 
pip install scikit-learn==0.24.1 
pip install tensorflow==2.11.0 
pip install Pillow==8.4.0 
pip install opencv-python==4.6.0.66 
pip install nltk==3.7 
pip install keras==2.11.0
===============================================
install all package
pip install Flask==2.1.0 Werkzeug==2.1.2 numpy==1.21.6 scikit-learn==0.24.1 tensorflow==2.11.0 Pillow==8.4.0 opencv-python==4.6.0.66 nltk==3.7 Sastrawi==1.0.1 keras==2.11.0